# package_calc

Description. 
The package package_name is used to:
	Calculadora
    - Calculos básicos

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name

```bash
pip install package_calc
```

## Usage

```python
from package_calc.calculadora import calculadora

calculadora.Calculadora()
```

## Author
Sormane

## License
[MIT](https://choosealicense.com/licenses/mit/)